import requests
from bs4 import BeautifulSoup
import re
from urllib.parse import urljoin, urlparse

def fetch_html(url):
    """Fetch HTML content from a URL."""
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch HTML: {e}")
        return None

def extract_css_links(html_content, base_url):
    """Extract all linked CSS URLs from HTML."""
    soup = BeautifulSoup(html_content, 'html.parser')
    css_links = []

    for link in soup.find_all('link', rel='stylesheet'):
        href = link.get('href')
        if href:
            full_url = href if href.startswith(('http://', 'https://')) else urljoin(base_url, href)
            css_links.append(full_url)

    return css_links

def fetch_css_content(css_url):
    """Fetch CSS content from a CSS file URL."""
    try:
        response = requests.get(css_url, timeout=10)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch CSS ({css_url}): {e}")
        return None

def extract_import_links(css_text, base_url):
    """Extract @import URLs from within a CSS file."""
    imports = re.findall(r'@import\s+(?:url\()?["\']?([^"\')]+)["\']?\)?;', css_text)
    full_import_links = [urljoin(base_url, imp) for imp in imports]
    return full_import_links

def extract_media_screen_blocks(css_text):
    """Extract all @media screen blocks from CSS content."""
    pattern = r'@media\s+screen[^{]*\{(?:[^{}]*\{[^{}]*\})*[^{}]*\}'
    return re.findall(pattern, css_text, re.DOTALL)

def save_to_file(content, filename):
    """Save the extracted media queries to a file."""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"[SUCCESS] Media queries saved to {filename}")
    except IOError as e:
        print(f"[ERROR] Failed to save file: {e}")

def crawl_all_css(urls):
    """Recursively crawl all CSS files including imported ones."""
    seen = set()
    media_queries = []

    while urls:
        css_url = urls.pop()
        if css_url in seen:
            continue

        seen.add(css_url)
        print(f"[INFO] Processing CSS: {css_url}")
        css_content = fetch_css_content(css_url)

        if css_content:
            # Extract media screens
            media_blocks = extract_media_screen_blocks(css_content)
            media_queries.extend(media_blocks)

            # Find and queue @imported CSS files
            imports = extract_import_links(css_content, css_url)
            for imp in imports:
                if imp not in seen:
                    urls.append(imp)

    return media_queries

def main():
    url = input("Enter the website URL: ").strip()
    html_content = fetch_html(url)

    if not html_content:
        return

    css_links = extract_css_links(html_content, url)
    if not css_links:
        print("[INFO] No CSS files found.")
        return

    print(f"[INFO] Found {len(css_links)} CSS files.")

    # Crawl all CSS including @import-ed ones
    media_queries = crawl_all_css(css_links)

    if media_queries:
        all_queries = "\n\n".join(media_queries)
        save_to_file(all_queries, "media_screen_queries.txt")
    else:
        print("[INFO] No @media screen blocks found.")

if __name__ == "__main__":
    main()